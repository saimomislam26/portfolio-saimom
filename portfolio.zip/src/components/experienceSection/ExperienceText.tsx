
const ExperienceText = () => {
  return (
    <div className="flex flex-col items-center mt-[100px]">
        <h2 className="text-cyan text-6xl mb-10">Experience</h2>
    </div>
  )
}

export default ExperienceText