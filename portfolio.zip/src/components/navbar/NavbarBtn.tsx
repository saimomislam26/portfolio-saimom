
import { LuArrowDownRight } from "react-icons/lu";
const NavbarBtn = () => {
  return (
    <button className="btn-custom">
      Hire Me
      <LuArrowDownRight/>
    </button>
  )
}

export default NavbarBtn