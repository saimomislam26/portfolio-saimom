

const NavbarLogo = () => {
  return (
    <div>
      <h1 className="text-white text-2xl sm:hidden md:block">Md. Saimom Islam</h1>
      <h1 className="text-white font-special text-3xl sm:block md:hidden">Saimom</h1>
    </div>
  )
}

export default NavbarLogo