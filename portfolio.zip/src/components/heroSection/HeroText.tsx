
const HeroText = () => {
    return (
        <div className="flex flex-col gap-4 h-full justify-center md:text-left sm:text-center">
            <h2 className="lg:text-2xl sm:text-xl uppercase text-cyan">Full Stack Web Developer</h2>
            <h1 className="md:text-[2.8rem] lg:text-6xl sm:text-4xl font-bold font-special text-orange">Md. Saimom Islam</h1>
            <p className="text-lg mt-4 text-white">Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem fugit dignissimos porro deserunt praesentium qui vitae quaerat illo, aut magnam assumenda vel! Magni commodi incidunt non soluta rerum, eaque fugit.</p>
        </div>
    )
}

export default HeroText